﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TargetType : MonoBehaviour {

	public enum TargetT
     {
         ldpi,
         mdpi,
         hdpi,
         xhdpi
     }

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
