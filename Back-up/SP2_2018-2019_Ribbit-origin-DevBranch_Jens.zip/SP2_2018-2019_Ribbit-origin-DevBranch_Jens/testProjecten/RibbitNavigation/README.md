# AR-Indoor-Navigation-System
Indoor navigation using Unity and Vuforia SDK. Prototype at Erasmus University Brussels 
