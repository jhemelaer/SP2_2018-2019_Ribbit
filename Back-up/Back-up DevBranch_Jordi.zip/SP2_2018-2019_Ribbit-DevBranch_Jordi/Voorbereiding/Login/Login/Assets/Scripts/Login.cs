﻿//Bronnen: https://www.youtube.com/watch?v=vFs0_skd0E4,
// https://www.youtube.com/watch?v=FBo9OdEF_D4,
// https://www.youtube.com/watch?v=Te5Qx-JAiOs

using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.Text.RegularExpressions;

public class Login : MonoBehaviour {

    public GameObject email;
    public GameObject wachtwoord;
    private string Email;
    private string Wachtwoord;
    private string DecryptedPass;

    public void LoginButton()
    {
        bool EM = false;
        bool PW = false;

        if (Email != "")
        {
            if(Email == "test@gmail.com")
            {
                EM = true;
            }
            else
            {
                Debug.LogWarning("E-mail niet gevonden in database");
            }
        }
        else
        {
            Debug.LogWarning("Geen e-mailadres ingevoerd");
        }

        if (Wachtwoord != "")
        {
            int i = 1;
            foreach(char c in Wachtwoord)
            {
                i++;
                char Decrypted = (char)(c / i);
                DecryptedPass += Decrypted.ToString();
            }

            if (Wachtwoord == DecryptedPass)
            {
                PW = true;
            }

            else
            {
                Debug.LogWarning("Wachtwoord niet correct");
            }
        }
        else
        {
            Debug.LogWarning("Geen wachtwoord ingevoerd");
        }

        if(EM == true && PW == true)
        {
            email.GetComponent<InputField>().text = "";
            wachtwoord.GetComponent<InputField>().text = "";
            print("Correct ingelogd");
        }
    }
	
	// Update is called once per frame
	void Update () {
        if(Input.GetKeyDown(KeyCode.Tab))
        {
            if(email.GetComponent<InputField>().isFocused)
            {
                wachtwoord.GetComponent<InputField>().Select();
            }

            if(Input.GetKeyDown(KeyCode.Return))
            {
                if(Email == "test@gmail.com" && Wachtwoord == "test")
                {
                    LoginButton();
                }
            }
        }
        Email = email.GetComponent<InputField>().text;
        Wachtwoord = wachtwoord.GetComponent<InputField>().text;
	}
}
